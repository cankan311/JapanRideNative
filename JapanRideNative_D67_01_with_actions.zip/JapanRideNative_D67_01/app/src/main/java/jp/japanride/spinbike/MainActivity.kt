package jp.japanride.spinbike

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import org.json.JSONObject
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("japan_ride_native", MODE_PRIVATE) }
    private val btAdapter: BluetoothAdapter? by lazy {
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private var scanner: BluetoothLeScanner? = null
    private var scanCallback: ScanCallback? = null
    private var heartGatt: BluetoothGatt? = null
    private var pendingAfterPermission: (() -> Unit)? = null

    private val heartServiceUuid = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb")
    private val heartMeasurementUuid = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb")
    private val batteryServiceUuid = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
    private val batteryLevelUuid = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")
    private val cccdUuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(true)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }
        webView.addJavascriptInterface(NativeHeartBridge(), "NativeHeartBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return !(url.startsWith("file:///android_asset/") || url.startsWith("https://") || url.startsWith("http://"))
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                sendSavedHeartState()
                // 起動直後、自動再接続を軽く試す。失敗しても画面起動は止めない。
                mainHandler.postDelayed({ reconnectSavedHeart(silent = true) }, 900)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeHeartBridge {
        @JavascriptInterface
        fun pairHeart() {
            postUi { ensureBlePermission { showHeartDevicePicker() } }
        }

        @JavascriptInterface
        fun reconnectHeart() {
            postUi { ensureBlePermission { reconnectSavedHeart(silent = false) } }
        }

        @JavascriptInterface
        fun disconnectHeart() {
            postUi { disconnectHeartGatt("切断しました") }
        }

        @JavascriptInterface
        fun forgetHeart() {
            postUi {
                disconnectHeartGatt("登録解除しました")
                prefs.edit().remove("heart_name").remove("heart_address").apply()
                sendHeartState(name = "未登録", connected = false, state = "未接続")
            }
        }
    }

    private fun postUi(block: () -> Unit) = mainHandler.post(block)

    private fun requiredBlePermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun hasBlePermission(): Boolean {
        return requiredBlePermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun ensureBlePermission(after: () -> Unit) {
        if (hasBlePermission()) {
            after()
            return
        }
        pendingAfterPermission = after
        requestPermissions(requiredBlePermissions(), 6701)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 6701 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            pendingAfterPermission?.invoke()
        } else if (requestCode == 6701) {
            sendHeartState(error = "Bluetooth権限が許可されていません", state = "権限なし")
        }
        pendingAfterPermission = null
    }

    @SuppressLint("MissingPermission")
    private fun showHeartDevicePicker() {
        val adapter = btAdapter
        if (adapter == null || !adapter.isEnabled) {
            sendHeartState(error = "BluetoothがOFFです", state = "Bluetooth OFF")
            return
        }
        stopScan()
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            sendHeartState(error = "BLEスキャンを開始できません", state = "検索失敗")
            return
        }

        val results = LinkedHashMap<String, ScanResult>()
        val labels = ArrayList<String>()
        val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        val listView = ListView(this)
        listView.adapter = listAdapter

        val dialog = AlertDialog.Builder(this)
            .setTitle("心拍センサーを選択")
            .setView(listView)
            .setNegativeButton("キャンセル") { _, _ -> stopScan(); sendSavedHeartState() }
            .create()

        listView.setOnItemClickListener { _, _, position, _ ->
            val key = labels.getOrNull(position)?.substringAfterLast("\n")?.trim()
            val result = key?.let { results[it] }
            if (result != null) {
                stopScan()
                dialog.dismiss()
                connectHeartDevice(result.device, save = true)
            }
        }

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device ?: return
                val address = device.address ?: return
                if (results.containsKey(address)) return
                results[address] = result
                val name = safeDeviceName(device, result) ?: "名称なし"
                val serviceHint = if (result.scanRecord?.serviceUuids?.any { it.uuid == heartServiceUuid } == true) " / 心拍対応" else ""
                labels.add("$name$serviceHint\n$address")
                listAdapter.notifyDataSetChanged()
            }

            override fun onScanFailed(errorCode: Int) {
                sendHeartState(error = "BLE検索に失敗しました: $errorCode", state = "検索失敗")
            }
        }

        dialog.setOnShowListener {
            sendHeartState(state = "検索中")
            scanner?.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scanCallback)
            mainHandler.postDelayed({
                stopScan()
                if (labels.isEmpty()) {
                    Toast.makeText(this, "候補が見つかりませんでした", Toast.LENGTH_SHORT).show()
                    sendHeartState(error = "候補が見つかりませんでした", state = "未検出")
                }
            }, 9000)
        }
        dialog.setOnDismissListener { stopScan() }
        dialog.show()
    }

    @SuppressLint("MissingPermission")
    private fun safeDeviceName(device: android.bluetooth.BluetoothDevice, result: ScanResult? = null): String? {
        return try { device.name } catch (_: SecurityException) { null }
            ?: result?.scanRecord?.deviceName
    }

    @SuppressLint("MissingPermission")
    private fun reconnectSavedHeart(silent: Boolean) {
        val address = prefs.getString("heart_address", null)
        val name = prefs.getString("heart_name", null)
        if (address.isNullOrBlank()) {
            if (!silent) sendHeartState(name = name ?: "未登録", connected = false, state = "保存済みなし", error = "保存済みの心拍計がありません")
            return
        }
        val adapter = btAdapter
        if (adapter == null || !adapter.isEnabled) {
            if (!silent) sendHeartState(name = name ?: "登録済み", connected = false, state = "Bluetooth OFF", error = "BluetoothがOFFです")
            return
        }
        try {
            val device = adapter.getRemoteDevice(address)
            connectHeartDevice(device, save = false)
        } catch (e: IllegalArgumentException) {
            sendHeartState(name = name ?: "登録済み", connected = false, state = "再接続失敗", error = "保存済みアドレスが無効です")
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectHeartDevice(device: android.bluetooth.BluetoothDevice, save: Boolean) {
        stopScan()
        heartGatt?.close()
        val name = safeDeviceName(device, null) ?: prefs.getString("heart_name", null) ?: "心拍センサー"
        if (save) {
            prefs.edit().putString("heart_name", name).putString("heart_address", device.address).apply()
        }
        sendHeartState(name = name, connected = false, state = "接続中")
        heartGatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(this, false, heartGattCallback, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
        } else {
            device.connectGatt(this, false, heartGattCallback)
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        try { scanCallback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
        scanCallback = null
    }

    @SuppressLint("MissingPermission")
    private fun disconnectHeartGatt(message: String) {
        try { heartGatt?.disconnect() } catch (_: Exception) {}
        try { heartGatt?.close() } catch (_: Exception) {}
        heartGatt = null
        sendHeartState(connected = false, state = message)
    }

    private val heartGattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val name = prefs.getString("heart_name", null) ?: safeDeviceName(gatt.device, null) ?: "心拍センサー"
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                sendHeartState(name = name, connected = true, state = "サービス確認中")
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sendHeartState(name = name, connected = false, state = "未接続")
                try { gatt.close() } catch (_: Exception) {}
                if (heartGatt === gatt) heartGatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val name = prefs.getString("heart_name", null) ?: safeDeviceName(gatt.device, null) ?: "心拍センサー"
            val battery = gatt.getService(batteryServiceUuid)?.getCharacteristic(batteryLevelUuid)
            if (battery != null) gatt.readCharacteristic(battery)

            val hr = gatt.getService(heartServiceUuid)?.getCharacteristic(heartMeasurementUuid)
            if (hr != null && enableNotification(gatt, hr)) {
                sendHeartState(name = name, connected = true, state = "心拍待ち")
            } else {
                sendHeartState(name = name, connected = true, state = "心拍通知なし", error = "標準BLE心拍通知が見つかりません")
            }
        }

        override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) handleCharacteristic(gatt, characteristic, characteristic.value)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            handleCharacteristic(gatt, characteristic, characteristic.value)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleCharacteristic(gatt, characteristic, value)
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableNotification(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic): Boolean {
        val ok = gatt.setCharacteristicNotification(characteristic, true)
        val descriptor = characteristic.getDescriptor(cccdUuid) ?: return ok
        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        return try { gatt.writeDescriptor(descriptor) } catch (_: Exception) { ok }
    }

    private fun handleCharacteristic(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray?) {
        val data = value ?: return
        val name = prefs.getString("heart_name", null) ?: safeDeviceName(gatt.device, null) ?: "心拍センサー"
        when (characteristic.uuid) {
            heartMeasurementUuid -> {
                val hr = parseHeartRate(data)
                if (hr > 0) sendHeartState(name = name, connected = true, hr = hr, state = "心拍受信中")
            }
            batteryLevelUuid -> {
                if (data.isNotEmpty()) sendHeartState(name = name, connected = true, battery = data[0].toInt() and 0xff, state = "接続中")
            }
        }
    }

    private fun parseHeartRate(data: ByteArray): Int {
        if (data.isEmpty()) return 0
        val flags = data[0].toInt() and 0xff
        return if ((flags and 0x01) != 0 && data.size >= 3) {
            (data[1].toInt() and 0xff) or ((data[2].toInt() and 0xff) shl 8)
        } else if (data.size >= 2) {
            data[1].toInt() and 0xff
        } else 0
    }

    private fun sendSavedHeartState() {
        val name = prefs.getString("heart_name", null) ?: "未登録"
        sendHeartState(name = name, connected = false, state = if (name == "未登録") "未接続" else "登録済み")
    }

    private fun sendHeartState(
        name: String? = prefs.getString("heart_name", null),
        connected: Boolean = false,
        hr: Int? = null,
        battery: Int? = null,
        state: String = if (connected) "接続中" else "未接続",
        error: String? = null
    ) {
        val payload = JSONObject().apply {
            put("native", true)
            put("name", name ?: "未登録")
            put("connected", connected)
            put("state", state)
            if (hr != null) put("hr", hr)
            if (battery != null) put("battery", battery)
            put("lastRx", java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.JAPAN).format(java.util.Date()))
            if (!error.isNullOrBlank()) put("error", error)
        }
        val js = "window.JapanRideNativeHeartUpdate && window.JapanRideNativeHeartUpdate($payload);"
        mainHandler.post { webView.evaluateJavascript(js, null) }
    }

    override fun onDestroy() {
        stopScan()
        try { heartGatt?.disconnect() } catch (_: Exception) {}
        try { heartGatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
