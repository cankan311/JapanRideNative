# Japan Ride Native D67-03 Shell No Kotlin Exact

GitHub Actionsで古いZIPを拾わないよう、workflow側でこのZIP名を指定して使うための安定版です。

- Kotlinなし
- Java WebView最小構成
- まずAPK生成を通すための版
- 心拍BLEは次段階で再追加
