package jp.japanride.spinbike;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(true);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);

        webView.addJavascriptInterface(new NativeHeartBridge(), "NativeHeartBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !(url.startsWith("file:///android_asset/") || url.startsWith("https://") || url.startsWith("http://"));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                sendHeartState("未登録", false, "ネイティブ土台起動", null, null, null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.grant(request.getResources());
            }
        });

        requestBasicPermissionsIfNeeded();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestBasicPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, 6701);
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 6702);
            }
        }
    }

    public class NativeHeartBridge {
        @JavascriptInterface
        public void pairHeart() {
            mainHandler.post(() -> {
                Toast.makeText(MainActivity.this, "D67-02では画面起動確認を優先しています", Toast.LENGTH_SHORT).show();
                sendHeartState("未登録", false, "未接続", null, null, "心拍接続は次版で再追加します");
            });
        }

        @JavascriptInterface
        public void reconnectHeart() {
            mainHandler.post(() -> sendHeartState("未登録", false, "保存済みなし", null, null, "保存済みの心拍計がありません"));
        }

        @JavascriptInterface
        public void disconnectHeart() {
            mainHandler.post(() -> sendHeartState("未登録", false, "切断しました", null, null, null));
        }

        @JavascriptInterface
        public void forgetHeart() {
            mainHandler.post(() -> sendHeartState("未登録", false, "登録解除しました", null, null, null));
        }
    }

    private void sendHeartState(String name, boolean connected, String state, Integer hr, Integer battery, String error) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("native", true);
            payload.put("name", name == null ? "未登録" : name);
            payload.put("connected", connected);
            payload.put("state", state == null ? "未接続" : state);
            if (hr != null) payload.put("hr", hr);
            if (battery != null) payload.put("battery", battery);
            if (error != null && !error.isEmpty()) payload.put("error", error);
            String js = "window.JapanRideNativeHeartUpdate && window.JapanRideNativeHeartUpdate(" + payload.toString() + ");";
            mainHandler.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception ignored) {}
    }
}
