# Japan Ride Native D67-04

Android WebView shell + native BLE RPM bridge.

- WebViewで現在のJapan Ride UIを表示
- Android Java側でBLEセンサー検索/保存済み再接続/切断/登録解除
- FITBOXなどFTMS Indoor Bike DataのRPM取得
- CSC Cycling Speed and CadenceのRPM取得
- Cycling Powerのクランク回転RPM取得
- 受信RPMをJavaScriptへ渡し、センサーRPM走行へ反映

GitHub Actionsでは、このZIP名を指定してビルドしてください。
