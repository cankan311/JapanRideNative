# Japan Ride Native D67-04b

D67-04のRPMネイティブ接続版。WebViewではWeb Bluetoothが使えないため、心拍センサーの旧Web Bluetooth UIを無効化し、D67-05で追加予定の表示に整理。

- Androidネイティブ側でFITBOX/RPM接続
- WebView内の旧Web Bluetooth心拍UIは無効化
- 既存workflowに合わせるため、アップロードZIP名は `JapanRideNative_D67_03_shell_no_kotlin_exact.zip` として配布
