# Japan Ride Native D67-04c

D67-04c: Android WebView shell + native RPM/cadence bridge.

- RPM / cadence is handled by Android native BLE bridge.
- Old Web Bluetooth heart sensor UI is disabled during D67-04.
- Heart-rate native integration is reserved for D67-05.

Use the existing GitHub Actions workflow that reads:
`JapanRideNative_D67_03_shell_no_kotlin_exact.zip`
