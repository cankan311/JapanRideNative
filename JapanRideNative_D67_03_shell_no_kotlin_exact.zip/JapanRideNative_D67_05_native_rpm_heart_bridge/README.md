# Japan Ride Native D67-05

Android WebView shell with native RPM bridge and native Heart Rate bridge.

- Native cadence/RPM BLE bridge
- Native Heart Rate BLE bridge
- Web Bluetooth heart UI replaced with native-only buttons
- Same zip filename can be used with the existing GitHub Actions workflow.
