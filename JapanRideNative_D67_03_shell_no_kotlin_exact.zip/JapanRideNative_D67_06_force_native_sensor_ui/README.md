# Japan Ride Native D67-06

Native sensor UI force fix. The settings sensor cards show NATIVE badges when this build is installed.
